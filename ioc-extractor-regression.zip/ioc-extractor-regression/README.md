# ioc-extractor regression suite

Real reports with independent ground truth, reviewed decisions and accepted baselines.
Run it after every change to the skill:

    python3 run.py --skill ../ioc-extractor          # all cases
    python3 run.py --skill ../ioc-extractor -k cisa  # some cases
    python3 run.py --skill ../ioc-extractor --update # accept a reviewed diff as the new baseline

Requires Python 3.10+, pdftotext (poppler-utils) and, optionally, jsonschema.

A case fails on: a missing ground-truth indicator, a new candidate with no review decision
(a new edge case to look at), a finalize or schema error, or any difference from the baseline.
Read the diff, decide whether it is an improvement, record decisions in the case's review.json,
then accept with --update.

To add a case: create cases/<name>/ with report.pdf or report.html (or ocr.txt), an optional
answer_key.txt (one indicator per line, only ones that appear in the report text), and a
review.json with decisions keyed "type|value". Run once to see undecided candidates, add their
decisions, then run with --update.

Ground truth sources: vendor IOC repositories (eset/malware-ioc, Cisco-Talos/IOCs, 360's IoC
page), or the report's own IOC section parsed independently of the extractor. The reports are
third-party publications kept here for internal testing only; do not redistribute them.
