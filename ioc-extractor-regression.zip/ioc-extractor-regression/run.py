#!/usr/bin/env python3
"""Regression suite for the ioc-extractor skill.

    python3 run.py --skill ../ioc-extractor            # run every case
    python3 run.py --skill ../ioc-extractor -k dfir    # cases whose name contains "dfir"
    python3 run.py --skill ../ioc-extractor --update   # accept current results as the new baseline

Each folder under cases/ holds:
  report.pdf | report.html   the source report (optional when ocr.txt is the only input)
  ocr.txt                    transcription of indicators shown only in images
  answer_key.txt             ground-truth indicators that appear in the report text (optional)
  review.json                review decisions keyed by "type|value", plus additions
  expected.json              baseline: candidates and final output from the last accepted run

A case fails when:
  - an answer-key indicator is missing from the final output (recall regression),
  - a candidate that needs a decision has none in review.json (new, unreviewed edge case),
  - finalize refuses the decisions, or the output breaks the JSON Schema,
  - the candidates or final output differ from expected.json (shown as a diff).
After checking a diff is an improvement, accept it with --update.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True)


def snapshot_candidates(doc: dict) -> list[dict]:
    snap = []
    for c in doc["candidates"] + doc["cves"]:
        item = {"type": c["type"], "value": c["value"], "in_ioc_section": c["in_ioc_section"]}
        for k in ("ambiguous_types", "validation_issue", "notes"):
            if c.get(k):
                item[k] = c[k]
        if c.get("rule_exclusion"):
            item["rule_exclusion"] = c["rule_exclusion"]["reason"]
        snap.append(item)
    return sorted(snap, key=lambda x: (x["type"], x["value"]))


def snapshot_output(out: dict) -> dict:
    return {
        "iocs": sorted(f"{t}|{e['value']}|{e['confidence']}|{e['extraction_method']}"
                       for t, v in out["iocs"].items() for e in v),
        "cves": sorted(c["value"] for c in out["cves"]),
        "excluded": sorted(f"{e['type']}|{e['value']}|{e['reason']}" for e in out["excluded"]),
        "needs_review": sorted(f"{e['type']}|{e['value']}|{e['issue']}" for e in out["needs_review"]),
        "warnings": sorted(w for w in out["warnings"] if not w.startswith("input_changed")),
    }


def diff_lists(name: str, old: list, new: list) -> list[str]:
    o = {json.dumps(x, sort_keys=True, ensure_ascii=False) for x in old}
    n = {json.dumps(x, sort_keys=True, ensure_ascii=False) for x in new}
    return [f"  {name} + {x}" for x in sorted(n - o)] + [f"  {name} - {x}" for x in sorted(o - n)]


def run_case(case: Path, skill: Path, update: bool, schema_validator) -> tuple[bool, list[str], dict]:
    script = skill / "scripts" / "extract_iocs.py"
    report = next(case.glob("report.*"), None)
    msgs: list[str] = []
    with tempfile.TemporaryDirectory() as tmp:
        cand_path = Path(tmp) / "candidates.json"
        cmd = ["python3", str(script), "extract", "--out", str(cand_path)]
        if report is not None:
            cmd += ["--text", str(report)]
        if (case / "ocr.txt").exists():
            cmd += ["--ocr", str(case / "ocr.txt")]
        r = run(cmd)
        if r.returncode != 0:
            return False, [f"  extract failed: {r.stderr.strip()[-500:]}"], {}
        cand = json.loads(cand_path.read_text(encoding="utf-8"))

        review = json.loads((case / "review.json").read_text(encoding="utf-8"))
        decisions, undecided = {}, []
        for c in cand["candidates"] + cand["cves"]:
            d = review["decisions"].get(f"{c['type']}|{c['value']}")
            if d is not None:
                decisions[c["id"]] = d
            elif c["type"] != "cve" and not c.get("rule_exclusion") and not c.get("validation_issue"):
                undecided.append(f"{c['type']}|{c['value']}  ctx: {c['contexts'][0][:140]}")
        if undecided:
            msgs.append(f"  {len(undecided)} new candidate(s) without a review decision:")
            msgs += [f"    {u}" for u in undecided]
            return False, msgs, {}
        dec_path = Path(tmp) / "decisions.json"
        dec_path.write_text(json.dumps({"decisions": decisions, "additions": review.get("additions", [])}))
        r = run(["python3", str(script), "finalize", "--candidates", str(cand_path), "--decisions", str(dec_path),
                 "--out-dir", tmp])
        if r.returncode != 0:
            return False, [f"  finalize failed: {r.stderr.strip()[-500:]}"], {}
        out = json.loads(r.stdout)

    ok = True
    if schema_validator is not None:
        errors = list(schema_validator.iter_errors(out))
        if errors:
            ok = False
            msgs += [f"  schema: {e.message[:200]}" for e in errors[:5]]

    stats = {"candidates": len(cand["candidates"]), "iocs": sum(len(v) for v in out["iocs"].values())}
    key_file = case / "answer_key.txt"
    if key_file.exists():
        key = {l.strip().lower() for l in key_file.read_text(encoding="utf-8").splitlines()
               if l.strip() and not l.startswith("#")}
        got = {e["value"].lower() for v in out["iocs"].values() for e in v}
        missed = sorted(key - got)
        stats["recall"] = f"{len(key) - len(missed)}/{len(key)}"
        if missed:
            ok = False
            msgs.append(f"  RECALL: {len(missed)} answer-key indicator(s) missing: {missed[:20]}")

    current = {"candidates": snapshot_candidates(cand), "output": snapshot_output(out)}
    exp_file = case / "expected.json"
    if update or not exp_file.exists():
        exp_file.write_text(json.dumps(current, indent=1, ensure_ascii=False), encoding="utf-8")
        msgs.append("  baseline written")
    else:
        exp = json.loads(exp_file.read_text(encoding="utf-8"))
        d = diff_lists("candidate", exp["candidates"], current["candidates"])
        for k in current["output"]:
            d += diff_lists(f"output.{k}", exp["output"].get(k, []), current["output"][k])
        if d:
            ok = False
            msgs.append(f"  {len(d)} difference(s) from baseline:")
            msgs += d[:60] + (["  ..."] if len(d) > 60 else [])
    return ok, msgs, stats


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--skill", default=str(HERE.parent / "ioc-extractor"))
    ap.add_argument("-k", default="", help="only cases whose name contains this")
    ap.add_argument("--update", action="store_true", help="accept current results as the baseline")
    args = ap.parse_args()
    skill = Path(args.skill).resolve()
    try:
        import jsonschema
        schema = json.loads((skill / "schema" / "ioc_output.schema.json").read_text())
        validator = jsonschema.Draft202012Validator(schema, format_checker=jsonschema.FormatChecker())
    except ImportError:
        validator = None
        print("note: jsonschema not installed, schema check skipped")

    cases = sorted(p for p in (HERE / "cases").iterdir() if p.is_dir() and args.k in p.name)
    failed = 0
    for case in cases:
        ok, msgs, stats = run_case(case, skill, args.update, validator)
        failed += not ok
        s = "  ".join(f"{k}={v}" for k, v in stats.items())
        print(f"{'PASS' if ok else 'FAIL'}  {case.name:<32} {s}")
        for m in msgs:
            print(m)
    print(f"\n{len(cases) - failed}/{len(cases)} cases passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
